// функция для переключения между страницами, в качестве аргумента примнимает путь к странице
function redirect(page) {
    window.location.href = page;
}

